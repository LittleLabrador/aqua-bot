const Discord = require('discord.js');
const client = new Discord.Client();
client.login('NzczNjM3NTMwNjc1MTgzNjE2.X6MIGA.QbPKK7vl-jI41AdlgiOKD7NTIbM');

client.on('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

client.on('message', msg => {
    if (msg.content === '$Aquarion') msg.reply(':aquarion: Welcome!   Do `!TRIBE_NAME` to join that tribe, and gain access to their channel!   To join Aquarion, do `!aquarion` , and gain access to #aquarion-acropolis !   We hope to see you there!  :aquarion:');
});

//dummy server stuff
const http = require('http');

http.createServer((rq, rs) => rs.end('What are you doing here?')).listen(process.env.PORT);